import Form from "./components/Form";
import UsersList from "./components/UsersList";
import { useState, useEffect } from "react";
// import axios from "axios";
import { RiseLoader } from "react-spinners";
import { getAllDataPaginated } from "./services/get.js";
import Pagination from "@mui/material/Pagination";
import Stack from "@mui/material/Stack";
import { LocalFireDepartmentOutlined } from "@mui/icons-material";

// const API_URL = "http://localhost:3000/users";

function App() {
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");
  const [update, setUpdate] = useState(0);
  const [page, setPage] = useState(0);
  const [total, setTotal] = useState(0);

  const fetchData = async () => {
    try {
      const response = await getAllDataPaginated(page);
      console.log(response);

      const { data, items } = response;
     // console.log(page);
      console.log(data);
      console.log(items);
      setTotal(items);
      setUsers(data);
    } catch (error) {
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [update,page]);

  return (
    <>
      <Form setUpdate={setUpdate} />
      {!error && !isLoading && (
        <UsersList users={users} setUpdate={setUpdate} />
      )}
      {isLoading && <RiseLoader />}
      {error && <p>{error}</p>}
      <Stack style={{ margin: "20px" }} spacing={4}>
      
        <Pagination
          count={total % 3==0 ? total / 3 : Math.floor(total / 3 )+1}
          variant="outlined"
          shape="rounded"
          onChange={(e, value) => {
            setPage(() => value);
          }}
        />
      </Stack>
    </>
  );
}

export default App;
