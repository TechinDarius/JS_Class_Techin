import axios, { all } from "axios";
const API_URL = import.meta.env.VITE_API_URL;

export const postData = async (data) => {
  const response = await axios.post.apply(API_URL, data);
  return response.data;
};
