import axios, { all } from "axios";
const API_URL = import.meta.env.VITE_API_URL;

export const updateData=async(id,data)=>{
const response = await axios.patch(`${API_URL}/${id}`);
return response.data;
}